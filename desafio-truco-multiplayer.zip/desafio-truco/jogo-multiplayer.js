const urlParams = new URLSearchParams(window.location.search);
const salaId = urlParams.get('sala');

if (!salaId) {
    alert("Sala não encontrada!");
    window.location.href = "index.html";
}

const salaRef = database.ref('salas/' + salaId);
let cartasJogador = [];

function embaralhar() {
    let baralhoCopia = ["4", "5", "6", "7", "Q", "J", "K", "A", "2", "3"];
    for (let i = baralhoCopia.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [baralhoCopia[i], baralhoCopia[j]] = [baralhoCopia[j], baralhoCopia[i]];
    }
    return baralhoCopia;
}

function distribuirCartas() {
    const cartas = embaralhar().slice(0, 3);
    salaRef.update({ cartas: cartas });
}

function mostrarCartas(cartas) {
    const divCartas = document.getElementById('cartas-jogador');
    divCartas.innerHTML = '';
    cartas.forEach(carta => {
        const cartaDiv = document.createElement('div');
        cartaDiv.className = 'carta';
        cartaDiv.innerText = carta;
        divCartas.appendChild(cartaDiv);
    });
}

function pedirTruco() {
    salaRef.update({ mensagem: "Alguém pediu TRUCO!" });
}

salaRef.on('value', snapshot => {
    const data = snapshot.val();
    if (data) {
        if (data.cartas) {
            cartasJogador = data.cartas;
            mostrarCartas(cartasJogador);
        }
        if (data.mensagem) {
            document.getElementById('mensagem').innerText = data.mensagem;
        }
    }
});

window.onload = () => {
    distribuirCartas();
};
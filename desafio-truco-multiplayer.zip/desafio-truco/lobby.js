function criarSala() {
    const salaId = Math.random().toString(36).substring(2, 8);
    database.ref('salas/' + salaId).set({
        cartas: [],
        mensagem: "",
    }).then(() => {
        window.location.href = 'jogo.html?sala=' + salaId;
    });
}

function entrarSalaPrompt() {
    const salaId = prompt("Digite o código da sala:");
    if (salaId) {
        window.location.href = 'jogo.html?sala=' + salaId;
    }
}